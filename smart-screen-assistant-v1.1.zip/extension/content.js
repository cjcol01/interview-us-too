// Screen capture + AI analysis content script

if (window._scapCtrl) window._scapCtrl.abort();
const ac = new AbortController();
window._scapCtrl = ac;

// If the extension context has been invalidated (e.g. after an extension update while
// this tab was open), every chrome.* call below would throw synchronously, meaning no
// listeners would ever be registered and the page would silently stop working.
// Signal the page first so it can show a "reload to reconnect" prompt, then abort.
try {
  void chrome.runtime.id;
} catch {
  document.dispatchEvent(new CustomEvent('scap:ext-stale'));
  throw new Error('[scap] Extension context invalidated — reload the page to reconnect.');
}

function _checkExtContext() {
  try { void chrome.runtime.id; } catch {
    document.dispatchEvent(new CustomEvent('scap:ext-stale'));
  }
}
document.addEventListener('visibilitychange', () => { if (!document.hidden) _checkExtContext(); }, { signal: ac.signal });
window.addEventListener('focus', _checkExtContext, { signal: ac.signal });

function showDisabledToast() {
  if (!window.location.pathname.startsWith('/app')) return;
  document.getElementById('_scap_disabled_toast')?.remove();
  const el = document.createElement('div');
  el.id = '_scap_disabled_toast';
  el.textContent = `Extension is disabled — press ${_hotkeys.toggle} to enable`;
  Object.assign(el.style, {
    position: 'fixed', bottom: '24px', right: '24px', zIndex: '2147483647',
    background: '#1e1e1e', color: '#fff', padding: '10px 16px', borderRadius: '8px',
    fontSize: '14px', fontFamily: 'sans-serif', boxShadow: '0 4px 12px rgba(0,0,0,0.4)',
    opacity: '1', transition: 'opacity 0.3s',
  });
  document.body.appendChild(el);
  setTimeout(() => { el.style.opacity = '0'; setTimeout(() => el.remove(), 300); }, 3000);
}

function showRateLimitToast(message) {
  if (!window.location.pathname.startsWith('/app')) return;
  const id = '_scap_ratelimit_toast';
  const existing = document.getElementById(id);
  if (existing) { existing.textContent = message; return; }
  const el = document.createElement('div');
  el.id = id;
  el.textContent = message;
  Object.assign(el.style, {
    position: 'fixed', bottom: '24px', right: '24px', zIndex: '2147483647',
    background: '#b45309', color: '#fff', padding: '10px 16px', borderRadius: '8px',
    fontSize: '14px', fontFamily: 'sans-serif', boxShadow: '0 4px 12px rgba(0,0,0,0.4)',
    opacity: '1', transition: 'opacity 0.3s',
  });
  document.body.appendChild(el);
  setTimeout(() => { el.style.opacity = '0'; setTimeout(() => el.remove(), 300); }, 4000);
}

const _onMessage = (msg) => {
  if (msg.type === 'toggled') {
    document.dispatchEvent(new CustomEvent('scap:toggled', { detail: { enabled: msg.enabled } }));
  } else if (msg.type === 'show-disabled') {
    showDisabledToast();
  } else if (msg.type === 'show-rate-limit') {
    showRateLimitToast(msg.message);
  } else if (msg.type === 'replay-buffer-empty') {
    showRateLimitToast('Replay buffer warming up — wait a moment and try again.');
  }
};
chrome.runtime.onMessage.addListener(_onMessage);
ac.signal.addEventListener('abort', () => chrome.runtime.onMessage.removeListener(_onMessage));

document.addEventListener('scap:hotkeys', (e) => {
  const { capture, audio, toggle, replay, typing } = e.detail;
  chrome.storage.local.set({ hotkey_capture: capture, hotkey_audio: audio, hotkey_toggle: toggle, hotkey_replay: replay, hotkey_typing: typing });
}, { signal: ac.signal });

document.addEventListener('scap:passthrough', (e) => {
  chrome.storage.local.set({ typing_passthrough: e.detail.enabled });
}, { signal: ac.signal });

document.addEventListener('scap:typing-preview', (e) => {
  chrome.storage.local.set({ typing_preview: e.detail.enabled });
}, { signal: ac.signal });

document.addEventListener('scap:replay', (e) => {
  const { enabled, seconds } = e.detail;
  chrome.storage.local.set({ replay_enabled: enabled, replay_seconds: seconds });
}, { signal: ac.signal });

// On /app and /support: push replay + mic + enabled status changes into the page as custom
// events. Unlike the 'toggled' message (sent only to whichever tab issued the toggle), this
// covers every tab showing these pages regardless of where the extension was actually
// toggled — hotkey, popup, or another tab entirely — since it's driven by storage.onChanged.
// /onboarding is in this list because its audio step shows live mic and instant-replay state
// while the user grants permission and locks a tab — without it those pushes never reach the
// page and the step can't tell whether anything worked.
if (window.location.pathname.startsWith('/app') || window.location.pathname.startsWith('/support')
    || window.location.pathname.startsWith('/onboarding')) {
  chrome.storage.local.get(['replay_status', 'mic_status', 'enabled'], ({ replay_status, mic_status, enabled }) => {
    if (replay_status) {
      document.dispatchEvent(new CustomEvent('scap:replay-status', { detail: replay_status }));
    }
    if (mic_status) {
      document.dispatchEvent(new CustomEvent('scap:mic-status', { detail: mic_status }));
    }
    document.dispatchEvent(new CustomEvent('scap:enabled-status', { detail: { enabled: enabled ?? false } }));
  });
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== 'local') return;
    if (changes.replay_status?.newValue) {
      document.dispatchEvent(new CustomEvent('scap:replay-status', {
        detail: changes.replay_status.newValue,
      }));
    }
    if (changes.mic_status?.newValue) {
      document.dispatchEvent(new CustomEvent('scap:mic-status', {
        detail: changes.mic_status.newValue,
      }));
    }
    if (changes.enabled?.newValue !== undefined) {
      document.dispatchEvent(new CustomEvent('scap:enabled-status', {
        detail: { enabled: changes.enabled.newValue },
      }));
    }
  });
}

// Read-only presence/link check — unlike scap:connect, never writes to storage,
// so it's safe to fire from any page without risking clobbering a real stored token.
document.addEventListener('scap:ping', () => {
  chrome.storage.local.get(['server_url', 'api_token'], ({ server_url, api_token }) => {
    // Deliberately not checking server_url === window.location.origin: captures always
    // go to the stored server_url regardless of which host the current tab is on (e.g.
    // 127.0.0.1 vs localhost are different origins but the same server), so requiring
    // an exact match here just produced false "not connected" reports.
    const linked = !!(server_url && api_token);
    const version = chrome.runtime.getManifest().version;
    document.dispatchEvent(new CustomEvent('scap:pong', { detail: { linked, version } }));
  });
}, { signal: ac.signal });

document.addEventListener('scap:mic-check', () => {
  chrome.runtime.sendMessage({ type: 'check-mic-permission' });
}, { signal: ac.signal });

// Distinct from mic-check, which only *queries* — the offscreen document is headless and can't
// show a permission prompt, so asking for the permission means opening grant-mic.html as a real
// tab. Until this existed the only way to reach that prompt was to fail a real capture, i.e. to
// find out your mic was blocked by pressing the hotkey during active use.
document.addEventListener('scap:mic-grant', () => {
  chrome.storage.local.set({ _open_mic_grant_ts: Date.now() });
}, { signal: ac.signal });

// The extension's mic permission lives at its own chrome-extension://<id> origin, which only
// this content script can look up (chrome.runtime.id isn't available to a regular page) — used
// by the support page's "Mic silent" card to link straight to the right settings entry instead
// of the generic microphone list, where it'd show up as an unlabeled chrome-extension:// origin
// among ordinary websites.
document.addEventListener('scap:mic-settings-link', () => {
  const url = 'chrome://settings/content/siteDetails?site='
    + encodeURIComponent('chrome-extension://' + chrome.runtime.id + '/');
  document.dispatchEvent(new CustomEvent('scap:mic-settings-link-result', { detail: { url } }));
}, { signal: ac.signal });

document.addEventListener('scap:enable', () => {
  // Only honour enable requests from the stored server's own origin — any arbitrary
  // page can dispatch DOM events, so without this check a malicious site could
  // silently arm the extension while the user is browsing elsewhere.
  chrome.storage.local.get(['server_url'], ({ server_url }) => {
    if (!server_url) return;
    try { if (new URL(server_url).origin !== window.location.origin) return; } catch { return; }
    chrome.runtime.sendMessage({ type: 'force-enable' });
  });
}, { signal: ac.signal });

document.addEventListener('scap:connect', (e) => {
  const { token, serverUrl } = e.detail;
  // Origin guard: if a server is already stored, only the page at that origin may
  // update credentials. First-time installs (nothing stored yet) are allowed through
  // so the onboarding flow can set the token without the user already being connected.
  chrome.storage.local.get(['server_url'], ({ server_url }) => {
    if (server_url) {
      try { if (new URL(server_url).origin !== window.location.origin) return; } catch { return; }
    }
    chrome.storage.local.set({ api_token: token, server_url: serverUrl }, () => {
      // The background service worker only pulls account settings (replay,
      // hotkeys, complexity, etc.) from the server once, at its own startup —
      // which happens before a fresh install has a token to sync with. Ask it
      // to sync now that one actually exists, or those settings stay empty
      // until the service worker happens to restart for an unrelated reason.
      chrome.runtime.sendMessage({ type: 'sync-account' });
      document.dispatchEvent(new CustomEvent('scap:connected'));
    });
  });
}, { signal: ac.signal });

// Mirrors HOTKEY_DEFAULTS in server.py — keep in sync. Overwritten by the user's own bindings
// once they arrive from the server; these only apply until then.
const _hotkeys = { toggle: 'Ctrl+Shift+1', capture: 'Ctrl+Shift+6', audio: 'Ctrl+Shift+7', replay: 'Ctrl+Shift+8', typing: 'Ctrl+Shift+9' };
let _audioRecording = false;
let _typingActive = false;
let _typingBuffer = '';
let _passthrough = true;
let _enabled = false;
let _hotkeysSuppressed = false;

document.addEventListener('scap:suppress-hotkeys', (e) => {
  _hotkeysSuppressed = !!e.detail?.suppress;
});

chrome.storage.local.get(['hotkey_capture', 'hotkey_audio', 'hotkey_toggle', 'hotkey_replay', 'hotkey_typing', 'typing_passthrough', 'enabled'], (r) => {
  if (r.hotkey_capture) _hotkeys.capture = r.hotkey_capture;
  if (r.hotkey_audio)   _hotkeys.audio   = r.hotkey_audio;
  if (r.hotkey_toggle)  _hotkeys.toggle  = r.hotkey_toggle;
  if (r.hotkey_replay)  _hotkeys.replay  = r.hotkey_replay;
  if (r.hotkey_typing)  _hotkeys.typing  = r.hotkey_typing;
  if (r.typing_passthrough !== undefined) _passthrough = r.typing_passthrough;
  if (r.enabled !== undefined) _enabled = r.enabled;
});

const _onStorageChanged = (changes) => {
  if (changes.hotkey_capture?.newValue) _hotkeys.capture = changes.hotkey_capture.newValue;
  if (changes.hotkey_audio?.newValue)   _hotkeys.audio   = changes.hotkey_audio.newValue;
  if (changes.hotkey_toggle?.newValue)  _hotkeys.toggle  = changes.hotkey_toggle.newValue;
  if (changes.hotkey_replay?.newValue)  _hotkeys.replay  = changes.hotkey_replay.newValue;
  if (changes.hotkey_typing?.newValue)  _hotkeys.typing  = changes.hotkey_typing.newValue;
  if (changes.typing_passthrough?.newValue !== undefined) _passthrough = changes.typing_passthrough.newValue;
  if (changes.enabled?.newValue !== undefined) _enabled = changes.enabled.newValue;
};
chrome.storage.onChanged.addListener(_onStorageChanged);
ac.signal.addEventListener('abort', () => chrome.storage.onChanged.removeListener(_onStorageChanged));

// Is the keystroke going somewhere that will actually consume it (a text box, a code editor)?
// Only used to decide whether a Space in typing mode would scroll the page instead of typing.
function typesIntoTarget(el) {
  // Walk into shadow roots: editors like Monaco/CodeMirror retarget the event to their host
  // element, so the real focused text box is one (or more) shadow boundaries down.
  while (el) {
    const tag = el.tagName;
    if (tag === 'INPUT' || tag === 'TEXTAREA' || tag === 'SELECT' || el.isContentEditable === true) return true;
    el = el.shadowRoot?.activeElement;
  }
  return false;
}

function parseHotkey(hotkey) {
  const parts = hotkey.toLowerCase().split('+').map(p => p.trim());
  const key = parts.find(p => !['ctrl', 'shift', 'alt'].includes(p)) || '';
  let code;
  if (/^\d$/.test(key))       code = 'Digit' + key;
  else if (/^[a-z]$/.test(key)) code = 'Key' + key.toUpperCase();
  else                           code = key;
  return { ctrl: parts.includes('ctrl'), shift: parts.includes('shift'), alt: parts.includes('alt'), code };
}

function matchesHotkey(e, hotkey) {
  const h = parseHotkey(hotkey);
  return (e.ctrlKey || e.metaKey) === h.ctrl
    && e.shiftKey === h.shift
    && e.altKey   === h.alt
    && e.code     === h.code;
}

// TYPING MODE NOTE: this listener intercepts keystrokes only when the user has manually
// activated typing mode via the typing hotkey (_typingActive === true). In all other
// states every keystroke passes through completely unobserved. capture:true is required
// so the extension's own toggle hotkey works even on pages that call stopPropagation
// on keydown (e.g. browser-based code editors).
document.addEventListener('keydown', (e) => {
  // The toggle hotkey always works, even while disabled or in typing mode — otherwise
  // there'd be no keyboard way back on. Checked before the typing-buffer branch below
  // so it can't be swallowed by the typing handler. Toggling also exits typing mode
  // since turning the extension off should clean up all active state.
  if (matchesHotkey(e, _hotkeys.toggle)) {
    if (e.repeat) return;
    e.preventDefault();
    e.stopPropagation();
    if (_typingActive) _typingActive = false;
    chrome.runtime.sendMessage({ type: 'toggle' });
    return;
  }

  // Disabled: don't intercept anything else — let every other keystroke (including this
  // tab's own typing) reach the page untouched instead of being swallowed and dropped.
  if (!_enabled) return;

  // Session-over modal open: block all capture hotkeys until dismissed.
  if (_hotkeysSuppressed) return;

  // Typing-mode toggle — checked first so it always stops capture, even mid-typing.
  if (matchesHotkey(e, _hotkeys.typing)) {
    if (e.repeat) return;
    e.preventDefault();
    e.stopPropagation();
    if (_typingActive) {
      _typingActive = false;
      const text = _typingBuffer;
      _typingBuffer = '';
      chrome.runtime.sendMessage({ type: 'typing-submit', text });
    } else {
      _typingActive = true;
      _typingBuffer = '';
      chrome.runtime.sendMessage({ type: 'typing-start' });
    }
    return;
  }

  // While typing mode is active, buffer keystrokes (basic fidelity: printable + Backspace).
  if (_typingActive) {
    // Enter ends capture and submits — it never appears in the buffer or on the page.
    if (e.key === 'Enter') {
      e.preventDefault();
      e.stopPropagation();
      _typingActive = false;
      const text = _typingBuffer;
      _typingBuffer = '';
      chrome.runtime.sendMessage({ type: 'typing-submit', text });
      return;
    }
    // Escape abandons the capture — buffer discarded, nothing sent. The
    // way out when you start typing and think better of it mid-question.
    if (e.key === 'Escape') {
      e.preventDefault();
      e.stopPropagation();
      _typingActive = false;
      _typingBuffer = '';
      chrome.runtime.sendMessage({ type: 'typing-cancel' });
      return;
    }
    if (e.key === 'Backspace') {
      _typingBuffer = _typingBuffer.slice(0, -1);
    } else if (e.key.length === 1 && !e.ctrlKey && !e.metaKey && !e.altKey) {
      _typingBuffer += e.key;
    } else {
      return;  // navigation/modifier keys: ignore and let them pass through
    }
    // .catch: the router answers nothing, so MV3 rejects the send promise with "message port
  // closed". Harmless, but unhandled it floods the page console on every keystroke.
  chrome.runtime.sendMessage({ type: 'typing-preview', text: _typingBuffer }).catch(() => {});
    if (!_passthrough) { e.preventDefault(); e.stopPropagation(); }
    // Passthrough deliberately lets keystrokes reach the page, but Space's page default is
    // "scroll down a screen" whenever focus isn't in a text field — so typing with
    // the editor unfocused would scroll the page down a paragraph per word.
    // Swallow only that default; the character is already in the buffer either way.
    else if (e.code === 'Space' && !typesIntoTarget(e.target) && !typesIntoTarget(document.activeElement)) e.preventDefault();
    return;
  }

  if (e.repeat) return;
  if (matchesHotkey(e, _hotkeys.audio) && !_audioRecording) {
    _audioRecording = true;
    chrome.runtime.sendMessage({ type: 'audio-start' });
  } else if (matchesHotkey(e, _hotkeys.capture)) {
    chrome.runtime.sendMessage({ type: 'capture' });
  } else if (matchesHotkey(e, _hotkeys.replay)) {
    chrome.runtime.sendMessage({ type: 'replay-trigger' });
  }
}, { capture: true, signal: ac.signal });

document.addEventListener('keyup', (e) => {
  if (!_audioRecording) return;
  const h = parseHotkey(_hotkeys.audio);
  const released = e.code === h.code
    || e.code === 'MetaLeft'    || e.code === 'MetaRight'
    || e.code === 'ShiftLeft'   || e.code === 'ShiftRight'
    || e.code === 'ControlLeft' || e.code === 'ControlRight'
    || e.code === 'AltLeft'     || e.code === 'AltRight';
  if (released) {
    _audioRecording = false;
    chrome.runtime.sendMessage({ type: 'audio-stop' });
  }
}, { capture: true, signal: ac.signal });

document.addEventListener('paste', (e) => {
  if (!_typingActive) return;
  const pasted = (e.clipboardData || window.clipboardData)?.getData('text') || '';
  if (!pasted) return;
  _typingBuffer += pasted;
  // .catch: the router answers nothing, so MV3 rejects the send promise with "message port
  // closed". Harmless, but unhandled it floods the page console on every keystroke.
  chrome.runtime.sendMessage({ type: 'typing-preview', text: _typingBuffer }).catch(() => {});
  if (!_passthrough) { e.preventDefault(); e.stopPropagation(); }
}, { capture: true, signal: ac.signal });
